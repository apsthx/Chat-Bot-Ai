$('#flash_message').delay(2000).fadeOut();
$('#flash_message4500').delay(4500).fadeOut();
$('#flash_message_1').delay(2000).fadeOut(1000);